# Medussa: A cross-platform high-level audio library for Python

## Contributors:

- [Joseph K. Ranweiler](https://github.com/ranweiler)
- [Ross Bencina](https://github.com/RossBencina)
- [Ryan W. Moore](https://github.com/ryanwmoore)
- [Kutay B. Sezginel](https://github.com/kbsezginel)
- [Andrzej Ciarkowski](https://github.com/andrzejc)


## Project Maintainer:

- [Christopher A. Brown](https://github.com/cbrown1): <cbrown1@pitt.edu>
